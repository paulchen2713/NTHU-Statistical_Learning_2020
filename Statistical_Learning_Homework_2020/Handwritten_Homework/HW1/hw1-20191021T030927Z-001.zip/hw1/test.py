# -*- coding: utf-8 -*-
"""
Created on Fri Mar 23 17:56:36 2018

@author: Yun
"""

# Data Preprocessing Template

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
import math as m
# =============================================================================
# Import All Data Set
# =============================================================================
# Importing the dataset
dataset = pd.read_csv('test.csv')
X1 = dataset.iloc[:, :-9].values
y1 = dataset.iloc[:, 1].values
# Splitting the dataset into the Training set and Test set
#X_train1, X_test1, y_train1, y_test1 = train_test_split(X1, y1, test_size = 0, random_state = 5)

X2 = dataset.iloc[:, -8:-7].values
y2 = dataset.iloc[:, 3].values
# Splitting the dataset into the Training set and Test set
#X_train2, X_test2, y_train2, y_test2 = train_test_split(X2, y2, test_size = 0, random_state = 7)

X3 = dataset.iloc[:, -6:-5].values
y3 = dataset.iloc[:, 5].values
# Splitting the dataset into the Training set and Test set
#X_train3, X_test3, y_train3, y_test3 = train_test_split(X3, y3, test_size = 0, random_state = 10)

X4 = dataset.iloc[:, -4:-3].values
y4 = dataset.iloc[:, 7].values
# Splitting the dataset into the Training set and Test set
#X_train4, X_test4, y_train4, y_test4 = train_test_split(X4, y4, test_size = 0, random_state = 0)

X5 = dataset.iloc[:, -2:-1].values
y5 = dataset.iloc[:, 9].values
# Splitting the dataset into the Training set and Test set
#X_train5, X_test5, y_train5, y_test5 = train_test_split(X5, y5, test_size = 0, random_state = 0)

X_train = np.vstack((X1,X2,X3,X4,X5))       # V stack
y_train = np.hstack((y1,y2,y3,y4,y5))       # horizontal stack

# =============================================================================
# Simple Linear Regression
# =============================================================================
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, y_train)
# Visualising the Training set results
plt.scatter(X_train, y_train, color = 'red')
plt.plot(X_train, regressor.predict(X_train), color = 'blue')
plt.title('Plot')
plt.xlabel('Discont')
plt.ylabel('Redemption Rate(Probability(')
plt.show()

# The coefficients
print('Coefficients: \n', regressor.coef_)
print('Intercept: \n', regressor.intercept_)

# List the fitted values for the above discount values
y_pred_5percent = regressor.predict(0.05)
y_pred_10percent = regressor.predict(0.10)
y_pred_15percent = regressor.predict(0.15)
y_pred_20percent = regressor.predict(0.20)
y_pred_30percent = regressor.predict(0.30)
#what price reduction will you get a 25% redemption rate?
#Coefficients: [ 1.69362933]    #Intercept: 0.10585071544
#X_25percnet_redemption = (0.25-regressor.intercept_)/(regressor.coef_).
y_pred_25percent = regressor.predict(0.25)
print('X_25percnet_redemption',y_pred_25percent)

# =============================================================================
#Logistict Regression 
# =============================================================================
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0, penalty = 'l1')
classifier.fit(X_train, y_train)
 
Cy_pred_5percent = classifier.predict(0.05)
Cy_pred_10percent = classifier.predict(0.10)
Cy_pred_15percent = classifier.predict(0.15)
Cy_pred_20percent = classifier.predict(0.20)
Cy_pred_30percent = classifier.predict(0.30)

Cy_predprob_5percent = classifier.predict_proba(0.05)
Cy_predprob_10percent = classifier.predict_proba(0.10)
Cy_predprob_15percent = classifier.predict_proba(0.15)
Cy_predprob_20percent = classifier.predict_proba(0.20)
Cy_predprob_30percent = classifier.predict_proba(0.30)

# The coefficients
print('\nCCoefficients: \n', classifier.coef_)
print('CIntercept: \n', classifier.intercept_)
#what price reduction will you get a 25% redemption rate?
#Coefficients: [ 2.73596805]    #Intercept: -0.75294411
#The problem has something BUG CX_25percnet_redemption = (m.log(1/((1/0.25)-1),m.e)-classifier.intercept_)/(classifier.coef_[0])
CX_25percnet_redemption = classifier.predict_proba(0.25)
print('CX_25percnet_redemption',CX_25percnet_redemption)

# =============================================================================
# 
# =============================================================================
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
lda = LinearDiscriminantAnalysis(solver="svd", store_covariance=True)
lda.fit(X_train, y_train)
lda.predict(0.25)

qda = QuadraticDiscriminantAnalysis(store_covariance=True)
qda.fit(X_train, y_train)
qda.predict(0.25)

