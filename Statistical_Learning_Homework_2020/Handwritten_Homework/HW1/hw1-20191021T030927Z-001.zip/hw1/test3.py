# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 22:24:43 2018
@建置環境 : Win10 、 Spyder
@author: Yun
@所有重點答案一律標記 ANS
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import statsmodels.api as sm
from mpl_toolkits.mplot3d import axes3d

from sklearn.metrics import mean_squared_error
from math import sqrt
# Importing the dataset
dataset = pd.read_csv('train_MNIST_logistic_regression.csv')
X_train = dataset.iloc[:,1:].values
X_train = sm.add_constant(X_train)
X_train = X_train.astype(int).reshape(np.shape(X_train))

y_train = dataset.iloc[:,0].values
y_train = y_train.astype(int).reshape(np.shape(y_train))

labelencoder_Y = LabelEncoder()
y_train[:] = labelencoder_Y.fit_transform(y_train[:])
# =============================================================================
# Use Libary
# =============================================================================
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
# A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
classifier.fit(X_train, y_train) 
LIB_y_train_pred = classifier.predict(X_train)
LIB_y_train_pred_prob = classifier.predict_proba(X_train)
classifier.coef_
classifier.intercept_

# =============================================================================
# 實際製作計算梯度下降法 ###.....ANS
# =============================================================================
B = np.zeros(785)
B  = B.reshape(785,1)

def compute_beta(B,X,y,step): ###.....ANS

    for ite in range(0,1000):
        Gradient  = np.zeros(785)
        Gradient = Gradient.reshape(785,1)
        for i in range(0,6999):
            tmp1 = np.dot(np.transpose(B),(np.transpose(X[i,:])).reshape((785,1)))
            Gradient = Gradient + ((2*y[i]-1)*(np.transpose(X[i,:])).reshape((785,1)))/(1+np.exp(-(2*y[i]-1)*tmp1))
        B = B+step*Gradient
    return B

new_B = compute_beta(B,X_train,y_train,0.0000000000001)

def Sigmoid(z):
	G_of_Z = float(1.0 / float((1.0 + np.exp(-1.0*z))))
	return G_of_Z

y_pred_prob = np.zeros(6999)
y_pred = np.zeros(6999)

for i in range(0,6999):
    y_pred_prob[i] = Sigmoid(np.dot((np.transpose(X_train[i,:])).reshape((1,785)),new_B))###.....ANS
    if Sigmoid(np.dot((np.transpose(X_train[i,:])).reshape((1,785)),new_B))>0.5:
       y_pred[i] = 2###.....ANS
# =============================================================================
# Confusion Matrix
# =============================================================================
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_train, y_pred) ###.....ANS
train_score = (cm[0,0]+cm[1,1])/6999  ###.....ANS
# =============================================================================
# ROC / AUC
# =============================================================================
from sklearn.metrics import roc_curve, auc
fpr, tpr, r = roc_curve(y_train, y_pred_prob)
roc_auc = auc(fpr, tpr)
plt.plot(fpr,tpr, color = 'blue', label='ROC curve (area = %0.2f)' % roc_auc) #畫線(X軸，Y軸，...)
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.legend()
plt.title('ROC Curve')
plt.xlabel('P(FP)')
plt.ylabel('P(TP)')
plt.show() ###.....ANS

# =============================================================================
# Test Dataset
# =============================================================================
# Importing the dataset
test_dataset = pd.read_csv('test_MNIST_logistic_regression.csv')
X_test = test_dataset.iloc[:,0:].values
X_test = sm.add_constant(X_test)
X_test = X_test.astype(int).reshape(np.shape(X_test))

#y_test = test_dataset.iloc[:,0].values
#y_test = y_test.astype(int).reshape(np.shape(y_test))
#labelencoder_Y = LabelEncoder()
#y_test[:] = labelencoder_Y.fit_transform(y_test[:])
y_test_pred_prob = np.zeros(1309)
y_test_pred = np.zeros(1309)
for i in range(0,1309):
    y_test_pred_prob[i] = Sigmoid(np.dot((np.transpose(X_test[i,:])).reshape((1,785)),new_B))###.....ANS
    if Sigmoid(np.dot((np.transpose(X_test[i,:])).reshape((1,785)),new_B))>0.5:
       y_test_pred[i] = 2###.....ANS
