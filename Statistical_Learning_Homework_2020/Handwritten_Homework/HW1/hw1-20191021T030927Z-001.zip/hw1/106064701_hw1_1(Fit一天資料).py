# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 23:10:11 2018
@建置環境:Win10 、 Spyder
@author: Yun
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@所有重點答案一律標記 ANS
@這邊我依照題意，一次只Fit的一天的觀察資料
@為了方便測試，我分別利用 函式庫 以及 實作的方式完成作業，還請助教注意，謝謝 :)
"""
# =============================================================================
# 第1-a
# 這邊我依照題意，一次只Fit的一天的觀察資料
# for loop 起初是為了Fit各別不同天的OLS模型 
# =============================================================================
# Simple Linear Regression 
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import statsmodels.api as sm
from mpl_toolkits.mplot3d import axes3d
from sklearn.metrics import mean_squared_error
from math import sqrt
# =============================================================================
# Noise Variance Estimation
# =============================================================================
def Noise(n,p,y,y_pred):
    N_var = (1/(n-p-1))*(sum([(y[i]-y_pred[i])**2 for i, element in enumerate(y)]))
    return N_var
# =============================================================================
# Std Error Fun.            
# =============================================================================
def coef_var(X_train,n_var):
   X_add = sm.add_constant(X_train)
   return np.linalg.pinv(np.dot(np.transpose(X_add),X_add))*(n_var)
    
# =============================================================================
# t-statistic
# =============================================================================
def t_statis(coef,coef_std_):
    t = np.zeros(len(coef))
    for i,ele in enumerate(coef):
        t[i] = coef[i]/sqrt(coef_std_[i][i])
    return t
# =============================================================================
# R2 
# =============================================================================
def R2(rss):
    y_mean = sum([y[i]/len(y) for i, element in enumerate(y)])
    Tss =  sum([(y[i]-y_mean)**2 for i, element in enumerate(y)])
    return 1-rss/Tss
# =============================================================================
# Linear Regression
# =============================================================================
def LR(X_trian, y,need_add):
    X_add = X_trian
    if need_add == True:
        X_add = sm.add_constant(X_trian)
    y_tmp = y.reshape((len(y),1))
    tmp = np.linalg.pinv(np.dot(np.transpose(X_add),X_add))
    coef = np.dot((np.dot(tmp,np.transpose(X_add))),y_tmp)
    return coef
# =============================================================================
# Linear Regression Predicted
# =============================================================================
def LR_pred(X_train,coef,need_add):
    X_add = X_train
    if need_add == True:
        X_add = sm.add_constant(X_train)
    return np.dot(X_add,coef)
# Importing the dataset
dataset = pd.read_csv('data_Hsinchu.csv',encoding = 'big5')
for i in range(0,1): #這邊我僅依照題意fit同一天的資料，
    X = dataset.iloc[[0+18*i,1+18*i,2+18*i,3+18*i,4+18*i,5+18*i,6+18*i,7+18*i,
                      8+18*i,10+18*i,11+18*i,12+18*i,13+18*i,14+18*i,15+18*i,16+18*i,17+18*i], 3:].values
    labelencoder_X = LabelEncoder()
    X[9, :] = labelencoder_X.fit_transform(X[9, :])
    X = X.astype(float).reshape(np.shape(X))
    X = np.transpose(X)
    y = dataset.iloc[9+18*i, 3:].values
    y = y.astype(float).reshape(np.shape(y))
    X2 = sm.add_constant(X)
    est = sm.OLS(y, X2)
    est2 = est.fit()
    print('第1-a對照表@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
    print(est2.summary())###########...ANS
# =============================================================================
# 1-a 
# =============================================================================
    print('第1-a@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
    LR_coef = LR(X,y,True)
    LR_y_predicted = LR_pred(X,LR_coef,True)
    LR_coef_var = coef_var(X,Noise(24,17,y,LR_y_predicted))
    LR_coef_std = np.asarray([LR_coef_var[i][i]**0.5 for i, element in enumerate(LR_coef)])
    LR_t = t_statis(LR_coef,LR_coef_var)
    from scipy import stats
    LR_pval = np.asarray([stats.t.sf(np.abs(LR_t[i]), 24-2)*2 for i, element in enumerate(LR_t)])
    # two-sided pvalue = Prob(abs(t)>tt)
    ANS_Matrix = np.stack((LR_coef.reshape((len(LR_coef),)),LR_coef_std,LR_t,LR_pval),axis = -1)
    print(ANS_Matrix)###########...ANS
    rss = sum([(LR_y_predicted[i][0] - y[i]) ** 2 for i, element in enumerate(y)])
    rse = sqrt((rss)/(24-2))
    print('R2 in ',i,' Days :', R2(rss),' \nRSE : ',rse) ###########...ANS    

# =============================================================================
# 第1-b( Select About RSS)
# =============================================================================
    print('第1-b@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
    min_RSS = 9999999
    for T in range(0,18):
        if T ==18:
            break
        for Q in range(1+T,18):
            X_tmp_add = sm.add_constant(X)
            X_select = X_tmp_add[:,[T,Q]]
            Select_LR_coef = LR(X_select,y,False)
            Select_LR_y_predicted2 = LR_pred(X_select,Select_LR_coef,False)
            rss = sum([(Select_LR_y_predicted2[i][0] - y[i]) ** 2 for i, element in enumerate(y)])
            if rss<min_RSS:
                min_RSS=rss
                min_RSS_coef = Select_LR_coef
                feature_index = [T,Q]
                rse = sqrt((min_RSS)/(24-2))
    print('R2 in ',i,' Days :', R2(min_RSS),' \nRSE : ',rse)  ###########...ANS   
    
    X_select = X_tmp_add[:,[feature_index[0],feature_index[1]]]#WD_HR + PM10...ANS
    Select_LR_coef = LR(X_select,y,False)
    Select_LR_y_predicted2 = LR_pred(X_select,Select_LR_coef,False)
    Select_LR_coef_var = coef_var(X_select,Noise(24,2,y,Select_LR_y_predicted2))
    Select_LR_coef_std = np.asarray([Select_LR_coef_var[i][i]**0.5 for i, element in enumerate(Select_LR_coef)])
    Select_LR_t = t_statis(Select_LR_coef,Select_LR_coef_var)
    Select_LR_pval = np.asarray([stats.t.sf(np.abs(Select_LR_t[i]), 24-2)*2 for i, element in enumerate(Select_LR_t)])
    # two-sided pvalue = Prob(abs(t)>tt)
    Select_ANS_Matrix = np.stack((Select_LR_coef.reshape((len(Select_LR_coef),)),Select_LR_coef_std,Select_LR_t,Select_LR_pval),axis = -1)
    print(Select_ANS_Matrix)###########...ANS
# =============================================================================
# 第1-c
# =============================================================================
# Create plot
    print('第1-C@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')            
    fig = plt.figure(figsize=(10,6))
    fig.suptitle('Regression: PM2.5 ~ WD_HR + PM10', fontsize=20)
    Tmp1 = np.arange(0,100,2)
    Tmp2 = np.arange(50,300,2)
    ax = axes3d.Axes3D(fig)
    B1, B2 = np.meshgrid(Tmp1, Tmp2)
    Z = np.zeros((Tmp2.size, Tmp1.size))
    for (i,j),v in np.ndenumerate(Z):
        Z[i,j] =B1[i,j]*Select_LR_coef[0] + B2[i,j]*Select_LR_coef[1]
    ax.plot_surface(B1, B2 ,Z , rstride=10, cstride=5, alpha=0.5)
    ax.scatter3D(X_tmp_add[:,feature_index[0]], X_tmp_add[:,feature_index[1]],y, c='r')
           
    ax.set_xlabel('PM10')
    ax.set_ylabel('WD_HR')
    ax.set_zlabel('PM2.5 in First Day') ###########...ANS


# =============================================================================
# Extra 使用函式庫
# =============================================================================
    from sklearn.linear_model import LinearRegression
    regressor = LinearRegression()
    regressor.fit(X, y)
    coef_LR = regressor.coef_
    coef_intercept_LR = regressor.intercept_
    y_predicted_LR = regressor.predict(X)
    rms = sqrt(mean_squared_error(y, y_predicted_LR))
    rss = sum((y_predicted_LR - y) ** 2)
    rse = sqrt((rss)/(24-2))
