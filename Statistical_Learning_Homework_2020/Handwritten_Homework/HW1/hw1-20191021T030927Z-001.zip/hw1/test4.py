# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 22:02:11 2018

@建置環境 : Win10 、 Spyder
@author: Yun
@所有重點答案一律標記 ANS
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import statsmodels.api as sm
from mpl_toolkits.mplot3d import axes3d
import math
from sklearn.metrics import mean_squared_error
from math import sqrt,log
# Importing the dataset
dataset = pd.read_csv('train_MNIST_LDA.csv')
X_train = dataset.iloc[:,1:].values
X_train = sm.add_constant(X_train)
X_train = X_train.astype(int).reshape(np.shape(X_train))

y_train = dataset.iloc[:,0].values
y_train = y_train.astype(int).reshape(np.shape(y_train))

#labelencoder_Y = LabelEncoder()
#y_train[:] = labelencoder_Y.fit_transform(y_train[:])

# =============================================================================
# u_kclass,var,phi_class calculate
# =============================================================================
def param_calcu(X_train,y_train):
    nclass = len(np.unique(y_train))
    u_kclass = []
    all_num = len(y_train)
    var = np.zeros((X_train.shape[1],X_train.shape[1]))
    phi = np.zeros(nclass)
    for i,element in enumerate(np.unique(y_train)) :
        num_class = np.sum(y_train == np.unique(y_train)[i]) 
        tmp = X_train[y_train == np.unique(y_train)[i],:]
        u_kclass.append((1/num_class)*np.sum(tmp,axis=0))
#        var = var + 1/(all_num-num_class)*np.sum((tmp-u_kclass[i])**2)#p=1
        for j in range(0,tmp.shape[0]):
            var = var + (1/(all_num-nclass))*np.dot((tmp[j]-u_kclass[i]).reshape((X_train.shape[1],1)),np.transpose((tmp[j]-u_kclass[i]).reshape((X_train.shape[1],1))))#P>1
        phi[i] = num_class/all_num
    return u_kclass,phi,var
# =============================================================================
# LDA
# =============================================================================
def delta_fun(x,k,u,phi,var):
#    tmp = x*u[k]/var-u[k]**2/(2*var)+log(phi[k])#P=1
    u = u[k].reshape(len(u[k]),1)
    tmp = np.dot(np.dot(np.transpose(x),np.linalg.pinv(var)),u)-0.5*np.dot(np.dot(np.transpose(u),np.linalg.pinv(var)),u)+log(phi[k])#P>1
    return tmp
#def prob_fun(x,k,u,phi,var): #此塊待修正
#    u = u[k].reshape(len(u[k]),1)
#    p = X_train.shape[1]
#    prob = (1/(math.pi)**(p/2))*(1/np.linalg.det(var####<<這邊不是，注意公式)**0.5)
#    prob = phi[k]*np.exp(-1/(2*var)*(x-u)**2)/(sum([phi[k]*np.exp(-1/(2*var)*(x-u))**2 for i, element in enumerate(u)]))
#    return prob
# =============================================================================
# Train
# =============================================================================
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
lda = LinearDiscriminantAnalysis(solver="svd", store_covariance=True)
lda.fit(X_train, y_train)
y_pred = np.zeros(10999)
y_pred = lda.predict(X_train)  ###.....ANS
train_score = lda.score(X_train,y_train)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_train, y_pred) ###.....ANS

# =============================================================================
# Test
# =============================================================================
# Importing the dataset
test_dataset = pd.read_csv('test_MNIST_LDA.csv')
X_test = test_dataset.iloc[:,0:].values
X_test = sm.add_constant(X_test)
X_test = X_test.astype(int).reshape(np.shape(X_test))

y_test_pred = np.zeros(10999)
y_test_pred = lda.predict(X_test)  ###.....ANS


# =============================================================================
# DIY Test Predicted
# =============================================================================
u_kclass,phi,var = param_calcu(X_train,y_train)
y_diy_pred = np.zeros(1381)
for i in range(0,1381):
    pred = 0
    for j in range(0,3):
        pred1 = delta_fun(X_test[i].reshape(len(X_test[i]),1),j,u_kclass,phi,var)
        if pred1>pred:
            pred = pred1
            y_diy_pred[i]=np.unique(y_train)[j] ###.....ANS
score = 0
for i in range(0,1381):
    if y_test_pred[i]!=y_diy_pred[i]:
        score = score+1
score = 1-score/1381 ###.....ANS